// config.js
const config = {
    API_BASE_URL: 'http://10.10.56.177:5001',
  };
  
export default config;
  
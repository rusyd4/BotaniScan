const plantImages = {
    "Barringtonia asiatica": require('./images/Barringtonia_asiatica.jpg'),
  };
  
 export default plantImages;
  